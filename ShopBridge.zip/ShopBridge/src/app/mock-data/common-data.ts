import { Item } from "../models/model-class";

export const ItemCategoriesList = [
    { itemValue: 1, itemName: 'Books' },
    { itemValue: 2, itemName: 'Electronics' },
    { itemValue: 3, itemName: 'Fashion' },
    { itemValue: 4, itemName: 'Home & Kitchen' },
    { itemValue: 5, itemName: 'Travel & Luggage' },
    { itemValue: 6, itemName: 'Sports' },
    { itemValue: 7, itemName: 'Toys' }
];
export const StandardItems: Array<Item> = [
    new Item(1, 1, 'Harry Potter and the Philosopher’s Stone', 20, 200, 'A journey into the world of magic where he is the celebrated Boy Who Lived. Visit Hogwarts, meet your favourite characters and watch Harry grow into the one of the most famous literary characters in the world.'),
    new Item(1, 2, 'The Great Gatsby', 10, 300, 'The Great Gatsby explores the decadence of the Jazz Age, and one man’s introduction into a world where even those with the most indulgent lives cannot earn love.'),
    new Item(1, 3, 'Pride and Prejudice', 30, 100, 'Pride And Prejudice details the courtship of two opposed characters in a world where manners and courtesy are of the utmost importance.'),
    new Item(1, 4, 'The Hobbit', 40, 400, 'The Hobbit was originally written as a short children’s book. Meet your favourite characters for the first time as the unforgettable Bilbo Baggins traverses the harsh landscapes of Middle Earth to challenge a dragon.'),
    new Item(2, 1, 'Television', 10, 500, 'watch the Discovery and History Channels.'),
    new Item(2, 2, 'Laptop/Computer', 20, 200, 'The Computer is one of the greatest inventions ever.'),
    new Item(2, 3, 'Smartphone', 60, 300, 'iPhone are the modern electronic devices through which we can see the entire world in a second and collect new information.'),
    new Item(2, 4, 'Washing Machine', 50, 100, 'very useful at present to wash clothes'),
    new Item(3, 1, 'Shoes Worn Over Pants', 70, 600, 'you can wrap a pair of strappy heels around the ankle of your cigarette pants, jeans, or slacks.'),
    new Item(3, 2, 'Chunky Boots with Feminine Dresses ', 10, 100, 'Grunge is back in a big way with these feminine dresses and chunky boots.'),
    new Item(3, 3, 'Maxi Faux Leather Coats', 20, 200, 'prefer to look sleek and high fashion or funky with a grunge twist, these long-line pieces are perfect for you.'),
    new Item(3, 4, 'Pastel Bucket Hats', 30, 400, 'Block out the sun and do it in style with a pastel bucket hat.'),
    new Item(4, 1, 'FOOD PROCESSOR', 40, 300, 'Food processors are awesome gadgets for making pates and dips, and mixing smooth and creamy deli-style tunafish.'),
    new Item(4, 2, 'SLOW COOKER', 10, 200, 'Many crock pot dishes from soups to beans can provide multiple meals: just freeze the leftovers to reheat on the stove top or microwave for weeks to come!'),
    new Item(4, 3, 'JUICER', 20, 100, 'Juicers can be bought at a low starting price.'),
    new Item(4, 4, 'BLENDER', 40, 200, 'They feature glass carafes and they look pretty snazzy on the countertop.'),
    new Item(5, 1, 'Victorinox Lexicon Hardside Large', 10, 400, 'The Victorinox Lexicon Large Hardside case is part of the esteemed brand’s most technically advanced collection of hardside luggage to date'),
    new Item(5, 2, 'Samsonite Octolite 75cm Spinner', 50, 200, 'Featuring an innovative design, this impressive suitcase is ideal for the modern traveler.'),
    new Item(5, 3, 'Samsonite Omni PC 28-Inch Spinner', 60, 500, 'Samsonite is known for producing some of the most high-quality and reliable suitcases on the market.'),
    new Item(5, 4, 'Antler Aire 4W', 50, 200, 'Antler’s Aire 4W Expanding Suitcase weighs in at just over two kilograms, making it the brand’s lightest soft case ever. '),
    new Item(6, 1, 'Balls', 20, 300, 'Sports like volleyball, basketball and football, as the name suggests, requires balls to play. '),
    new Item(6, 2, 'Sticks, Bats And Clubs', 10, 100, 'These are sports equipment, which are used in games like golf, baseball, cricket and hockey.'),
    new Item(6, 3, 'Gears', 30, 400, 'Gears also include jackets, shirts and protective gears which are used while playing.'),
    new Item(6, 4, 'Rods And Tackles', 10, 300, 'Rods and tackles are equipment used in fishing.'),
    new Item(7, 1, '​Rubik’s Cube', 40, 500, 'According to the National Toy Hall of Fame, the 3-D cube is the most popular puzzle in history.'),
    new Item(7, 2, 'LEGO', 30, 400, 'LEGO has redefined the potential of playthings, allowing kids to build permanent structures from scratch, in all kinds of shapes and sizes'),
    new Item(7, 3, 'Barbie', 10, 200, 'She also had a significant impact on social values by conveying characteristics of female independence, diversity.'),
    new Item(7, 4, 'Chess', 20, 600, 'Chess is a recreational and competitive board game played between two players​.')
]