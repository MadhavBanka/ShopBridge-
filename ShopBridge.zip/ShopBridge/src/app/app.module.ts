import { BrowserModule } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
 
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
 
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { AppBody } from './components/page-body/page-body';
import { AddOrEditItems } from './components/add-edit-item/add-edit-item';
import { ItemDetails } from './components/item-details/item-details';
import { AppHeader } from './components/page-header/page-header';
 
@NgModule({
  declarations: [
    AppComponent,
    AppHeader,
    AppBody,
    AddOrEditItems,
    ItemDetails
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    DropDownsModule
  ],
  providers: [],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
  
})
export class AppModule { }