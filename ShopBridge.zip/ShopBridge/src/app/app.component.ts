import { Component, OnChanges, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnChanges {
  title = 'ShopBridge';
  public selectedCategory = 0;

  ngOnChanges(){

  }
  ngOnInit(){
    
  }

  categoryFilter(event) {
    if (event) {
      if (event.hasOwnProperty('category')) {
        this.selectedCategory = event.category;
      }
    }
  }
  
}
