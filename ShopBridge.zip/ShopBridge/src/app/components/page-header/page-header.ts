import { Component, EventEmitter, OnChanges, OnInit, Output } from "@angular/core";
import { ItemCategoriesList } from "src/app/mock-data/common-data";

@Component({
  selector: 'app-page-header',
  templateUrl: './page-header.html',
  styleUrls: ['./page-header.css']
})

export class AppHeader implements OnInit, OnChanges {
  public listItems: Array<any> = ItemCategoriesList;
  public defaultCategory = { itemValue: null, itemName: 'Select Category' };

  @Output() selectedCategory = new EventEmitter<any>();

  constructor() {

  }
  ngOnChanges() {

  }
  ngOnInit() {
    // this.listItems.unshift({ itemValue: 0, itemName: 'All' });
  }

  categoryChange(event: any) {
    console.log(event);
    if (event) {
      this.selectedCategory.emit({ category: event.itemValue });
    }
  }
}