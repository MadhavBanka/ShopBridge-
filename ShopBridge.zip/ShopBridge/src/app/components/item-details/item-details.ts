import { OnChanges, OnInit } from "@angular/core";
import { Component, Input } from "@angular/core";
import { StandardItems } from "src/app/mock-data/common-data";
import { Item } from "src/app/models/model-class";

@Component({
  selector: 'app-item-details',
  templateUrl: './item-details.html',
  styleUrls: ['./item-details.css']
})

export class ItemDetails implements OnInit, OnChanges {
  @Input() itemDetails: Array<Item>;
  public showItemDetails = true;
  public addOrEditItemType = 'edit';
  public passingEditItem;
  constructor() {

  }
  ngOnChanges() {
    console.log('ngOnChanges', this.itemDetails);
  }
  ngOnInit() {
  }
  editItem(event: any, editItem: any) {
    this.showItemDetails = false;
    this.passingEditItem = editItem;
  }
  deleteItem(event: any, delItem: Item) {
    let idx = 0;
    for (const item of this.itemDetails) {
      if (item.category == delItem.category && item.itemId == delItem.itemId) {
        break;
      }
      idx++;
    }
    this.itemDetails.splice(idx,1);
    for (const item of StandardItems) {
      if (item.category == delItem.category && item.itemId == delItem.itemId) {
        break;
      }
      idx++;
    }
    StandardItems.splice(idx,1);
  }
  addEditItemChange(event: any) {
    if (event) {
      if (event.hasOwnProperty('closeModal')) {
        this.showItemDetails = event.closeModal;
      }
      if (event.hasOwnProperty('itemInfo')) {
        this.itemDetails.unshift(event.itemInfo);
      }
    }
  }
}