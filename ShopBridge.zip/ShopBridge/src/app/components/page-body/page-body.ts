import { Component, Input, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { StandardItems } from "src/app/mock-data/common-data";
import { Item } from "src/app/models/model-class";

@Component({
    selector: 'app-page-body',
    templateUrl: './page-body.html',
    styleUrls: ['./page-body.css']
  })

  export class AppBody implements OnInit, OnChanges {

    @Input() headerSelCategory = 0;

    public itemDetails: Array<Item> = StandardItems;
    public showItemDetails = true;

    constructor(){
    }
    ngOnChanges(changes: SimpleChanges){
      console.log(changes);
      if (changes && changes.headerSelCategory && changes.headerSelCategory.currentValue) {
        const selCategory = changes.headerSelCategory.currentValue;
        this.itemDetails = [];
        for (const item of StandardItems) {
          if (item.category === selCategory) {
            this.itemDetails.push(item);
          }
        }
      }
    }
    ngOnInit(){
        
    }
    addNewItem() {
      this.showItemDetails = false;
    }
    addEditItemChange(event) {
      if (event) {
        if (event.hasOwnProperty('closeModal')) {
          this.showItemDetails = event.closeModal;
        }
        if (event.hasOwnProperty('itemInfo')) {
          StandardItems.unshift(event.itemInfo);
          this.itemDetails.unshift(event.itemInfo);
        }
      }
    }
  }