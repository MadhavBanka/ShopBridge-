import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from "@angular/core";
import { ItemCategoriesList, StandardItems } from "src/app/mock-data/common-data";
import { Item } from "src/app/models/model-class";

@Component({
  selector: 'app-add-edit-item',
  templateUrl: './add-edit-item.html',
  styleUrls: ['./add-edit-item.css']
})

export class AddOrEditItems implements OnInit, OnChanges {

  public itemCategoryList: Array<any> = ItemCategoriesList;
  @Input() addOrEditItemTag = 'add';
  @Input() itemToEdit: Item;
  @Output() closeAddingEditing = new EventEmitter<any>();

  public addEditItemObj: Item = new Item(null, null, null, null, null, null);
  public defaultCategory = { itemValue: null, itemName: 'Select Category' };
  public showErrorMessage = false;
  public errorMessage: string;

  constructor() {
  }
  ngOnChanges(changes: SimpleChanges) {
    if (changes && changes.itemToEdit && changes.itemToEdit.currentValue) {
      this.addEditItemObj = changes.itemToEdit.currentValue;
      for (const category of ItemCategoriesList) {
        if(category.itemValue === this.addEditItemObj.category) {
          this.defaultCategory = category;
          break;
        }
      }
    }
  }
  ngOnInit() {
  }
  closeAddEditItem() {
    this.closeAddingEditing.emit({ closeModal: true });
  }

  categoryChange(event: any) {
    if (event) {
      this.addEditItemObj.category = event.itemValue;
    } else {
      this.addEditItemObj.category = null;
    }
  }

  itemNameChange(event: any) {    
    const charCode = event.charCode;
    const txtValue = this.addEditItemObj.itemName;
    if ((txtValue && txtValue.length === 1) && charCode === 32) {
      return false;
    }
    if ((65 <= charCode && charCode <= 90) || (97 <= charCode && charCode <= 122) || charCode === 32) {
      return true;
    }
    return false;
  }
  
  quantityPriceChange(event: any, type: string) {
    const charCode = event.charCode;
    const txtValue = this.addEditItemObj[type];
    if ((txtValue && txtValue.length === 1) && (txtValue[0] === '0' || txtValue[0] === 0)) {
        return false;
    }
    if (47 < charCode && charCode < 58) {
        return true;
    }
    return false;
  }

  addOrEditItem() {
    console.log(this.addEditItemObj);
    this.showErrorMessage = true;
    this.errorMessage = '';
    if (this.addEditItemObj.category === null) {
      this.errorMessage = 'Select any Category';
      return;
    }
    if (this.addEditItemObj.itemName === null || this.addEditItemObj.itemName === '' || this.addEditItemObj.itemName === ' ') {
      this.errorMessage = 'Enter Item Name';
      return;
    }
    if (this.addEditItemObj.quantity === null) {
      this.errorMessage = 'Enter Quantity';
      return;
    }
    if (this.addEditItemObj.price === null) {
      this.errorMessage = 'Enter Price';
      return;
    }
    if (this.addEditItemObj.description === null) {
      this.errorMessage = 'Enter Item Description';
      return;
    }
    this.showErrorMessage = false;
    let curMaxItemId = Number.MIN_SAFE_INTEGER;
    for (const item of StandardItems) {
      if (item.category === this.addEditItemObj.category) {
        if (item.itemId > curMaxItemId)
          curMaxItemId = Number(item.itemId);
      }
    }
    this.addEditItemObj.itemId = ++curMaxItemId;
    this.closeAddingEditing.emit({ closeModal: true, itemInfo: this.addEditItemObj });
  }
}
